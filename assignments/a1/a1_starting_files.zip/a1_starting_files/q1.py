# q1.py

#
# Full Name:
# SD43 Email:
#

# ... put your answer to question 1 here ...
