# q4.py

#
# Full Name:
# SD43 Email:
#

# ... put your answer to question 4 here ...
