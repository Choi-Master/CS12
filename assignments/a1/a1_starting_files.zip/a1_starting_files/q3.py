# q3.py

#
# Full Name:
# SD43 Email:
#

# ... put your answer to question 3 here ...
